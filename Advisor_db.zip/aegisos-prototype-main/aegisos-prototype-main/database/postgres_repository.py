"""PostgreSQL-backed student repository for AegisOS.

This mirrors the public interface of database.repository.StudentRepository
(the SQLite version) so it can be swapped in without changing callers in
backend/app.py: same Student shape, same get_student(student_id) contract.

Data comes from the normalized AegisOS schema (programs, courses, students,
student_courses, student_goals, course_prerequisites, program_courses)
instead of a flat SQLite students.csv seed.

Field mapping notes (the normalized schema doesn't store `year`/`gpa`
directly, so they are derived):
- name    <- students.full_name
- major   <- programs.program_name (via students.program_id)
- year    <- students.academic_level
- gpa     <- computed from letter grades in student_courses where
             status = 'Completed' and grade is not null (4.0 scale,
             +/- steps of 0.33, standard US-style mapping). Returns
             None if the student has no graded completed courses yet.
- courses <- course titles where student_courses.status = 'Current'
             (i.e. courses the student is presently enrolled in --
             this matches how /workspace/create and /workspace/vscode
             use `courses` to validate enrollment before opening a
             workspace).
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Optional

import psycopg2
import psycopg2.extras


GRADE_POINTS: dict[str, float] = {
    "A+": 4.0, "A": 4.0, "A-": 3.7,
    "B+": 3.3, "B": 3.0, "B-": 2.7,
    "C+": 2.3, "C": 2.0, "C-": 1.7,
    "D+": 1.3, "D": 1.0, "D-": 0.7,
    "F": 0.0,
}


@dataclass(frozen=True)
class Student:
    student_id: str
    name: str
    major: str
    year: int
    gpa: Optional[float]
    courses: tuple[str, ...]

    def as_dict(self) -> dict[str, object]:
        return {
            "student_id": self.student_id,
            "name": self.name,
            "major": self.major,
            "year": self.year,
            "gpa": self.gpa,
            "courses": list(self.courses),
        }


class PostgresStudentRepository:
    """Same public contract as database.repository.StudentRepository,
    backed by PostgreSQL instead of SQLite.
    """

    def __init__(self, dsn: str) -> None:
        self.dsn = dsn

    def _connect(self):
        return psycopg2.connect(self.dsn, cursor_factory=psycopg2.extras.RealDictCursor)

    def initialize(self) -> None:
        """No-op: the normalized schema is created and seeded separately
        in pgAdmin. Kept only so app.py can call repository.initialize()
        the same way it does for the SQLite repository.
        """
        return None

    def get_student(self, student_id: str) -> Optional[Student]:
        normalized_id = student_id.strip()
        with self._connect() as connection:
            with connection.cursor() as cursor:
                cursor.execute(
                    """
                    SELECT s.student_id, s.full_name, s.academic_level, p.program_name
                    FROM students s
                    JOIN programs p ON p.program_id = s.program_id
                    WHERE s.student_id = %s
                    """,
                    (normalized_id,),
                )
                student_row = cursor.fetchone()
                if student_row is None:
                    return None

                cursor.execute(
                    """
                    SELECT c.course_title, sc.grade
                    FROM student_courses sc
                    JOIN courses c ON c.course_id = sc.course_id
                    WHERE sc.student_id = %s AND sc.status = 'Completed'
                    """,
                    (normalized_id,),
                )
                completed_rows = cursor.fetchall()

                cursor.execute(
                    """
                    SELECT c.course_title
                    FROM student_courses sc
                    JOIN courses c ON c.course_id = sc.course_id
                    WHERE sc.student_id = %s AND sc.status = 'Current'
                    ORDER BY c.course_title
                    """,
                    (normalized_id,),
                )
                current_rows = cursor.fetchall()

        gpa = self._compute_gpa(completed_rows)
        courses = tuple(row["course_title"] for row in current_rows)

        return Student(
            student_id=student_row["student_id"],
            name=student_row["full_name"],
            major=student_row["program_name"],
            year=student_row["academic_level"],
            gpa=gpa,
            courses=courses,
        )

    @staticmethod
    def _compute_gpa(completed_rows: list) -> Optional[float]:
        points = [
            GRADE_POINTS[row["grade"]]
            for row in completed_rows
            if row["grade"] in GRADE_POINTS
        ]
        if not points:
            return None
        return round(sum(points) / len(points), 2)
