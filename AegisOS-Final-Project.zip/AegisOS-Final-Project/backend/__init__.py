"""AegisOS EDU FastAPI backend."""
