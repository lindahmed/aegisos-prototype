"""Smart semester planning services."""
