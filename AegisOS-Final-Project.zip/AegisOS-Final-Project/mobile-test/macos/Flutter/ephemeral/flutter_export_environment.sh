#!/bin/sh
# This is a generated file; do not edit or check into version control.
export "FLUTTER_ROOT=/Users/hamsaa/Desktop/development/flutter"
export "FLUTTER_APPLICATION_PATH=/Users/hamsaa/Desktop/aegisos-prototype-main/mobile-test"
export "FLUTTER_FRAMEWORK_SWIFT_PACKAGE_PATH=/Users/hamsaa/Desktop/aegisos-prototype-main/mobile-test/macos/Flutter/ephemeral/Packages/.packages/FlutterFramework"
export "COCOAPODS_PARALLEL_CODE_SIGN=true"
export "FLUTTER_BUILD_DIR=build"
export "FLUTTER_BUILD_NAME=1.1.0"
export "FLUTTER_BUILD_NUMBER=3"
export "DART_OBFUSCATION=false"
export "TRACK_WIDGET_CREATION=true"
export "TREE_SHAKE_ICONS=false"
export "PACKAGE_CONFIG=.dart_tool/package_config.json"
